<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-12 07:12:38 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-12 14:27:16 --> Severity: Notice --> Undefined index: kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 598
ERROR - 2023-07-12 14:27:20 --> Severity: Notice --> Undefined index: kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 598
ERROR - 2023-07-12 14:27:47 --> Severity: Notice --> Undefined index: kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 598
ERROR - 2023-07-12 14:31:39 --> Severity: Notice --> Undefined index: kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 626
ERROR - 2023-07-12 14:32:25 --> Severity: Notice --> Undefined index: kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 626
ERROR - 2023-07-12 14:45:14 --> Severity: Notice --> Undefined index: kode_sbu C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 819
ERROR - 2023-07-12 14:45:19 --> Severity: Notice --> Undefined index: kode_sbu C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 819
ERROR - 2023-07-12 14:45:59 --> Severity: Notice --> Undefined index: id_url C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 880
ERROR - 2023-07-12 14:45:59 --> Severity: Notice --> Undefined index: id_vendor_sbu C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 883
ERROR - 2023-07-12 14:46:59 --> Severity: Notice --> Undefined index: id_vendor_sbu C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 883
ERROR - 2023-07-12 15:44:17 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
ERROR - 2023-07-12 15:47:46 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
ERROR - 2023-07-12 15:51:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 254
ERROR - 2023-07-12 15:51:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 306
ERROR - 2023-07-12 15:51:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 307
ERROR - 2023-07-12 15:51:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 309
ERROR - 2023-07-12 15:51:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 310
ERROR - 2023-07-12 15:51:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 317
ERROR - 2023-07-12 15:51:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 319
ERROR - 2023-07-12 15:52:28 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
ERROR - 2023-07-12 15:53:26 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
ERROR - 2023-07-12 15:53:55 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
ERROR - 2023-07-12 15:54:08 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
ERROR - 2023-07-12 15:57:56 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
ERROR - 2023-07-12 15:58:10 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
