<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-08 05:05:35 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-08 12:07:34 --> Severity: error --> Exception: Too few arguments to function Data_kbli::get_row_data(), 0 passed in C:\laragon\www\eproc-jmto\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\eproc-jmto\application\controllers\validator\Data_kbli.php 92
ERROR - 2023-07-08 12:07:36 --> Severity: error --> Exception: Too few arguments to function Data_kbli::get_row_data(), 0 passed in C:\laragon\www\eproc-jmto\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\eproc-jmto\application\controllers\validator\Data_kbli.php 92
ERROR - 2023-07-08 12:07:41 --> Severity: error --> Exception: Too few arguments to function Data_kbli::get_row_data(), 0 passed in C:\laragon\www\eproc-jmto\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\eproc-jmto\application\controllers\validator\Data_kbli.php 92
ERROR - 2023-07-08 12:07:51 --> Severity: error --> Exception: Too few arguments to function Data_kbli::get_row_data(), 0 passed in C:\laragon\www\eproc-jmto\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\eproc-jmto\application\controllers\validator\Data_kbli.php 92
ERROR - 2023-07-08 12:07:58 --> Severity: error --> Exception: Too few arguments to function Data_kbli::get_row_data(), 0 passed in C:\laragon\www\eproc-jmto\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\eproc-jmto\application\controllers\validator\Data_kbli.php 92
ERROR - 2023-07-08 13:14:39 --> Query error: Unknown column 'kode_kbli' in 'order clause' - Invalid query: SELECT *
FROM `tbl_sbu`
ORDER BY `kode_kbli` ASC
 LIMIT 10
ERROR - 2023-07-08 13:22:58 --> Severity: Warning --> readfile(http://localhost/vms-jmto/file_vms/PT TOWER INDONESIA/SIUP-2023/tahap_1.pdf): failed to open stream: HTTP request failed! HTTP/1.1 400 Bad Request
 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 333
ERROR - 2023-07-08 13:23:00 --> Severity: Warning --> readfile(http://localhost/vms-jmto/file_vms/PT TOWER INDONESIA/NIB-2023/ALUR_PROSES_E-CATALOG_JMTM_(1)1.pdf): failed to open stream: HTTP request failed! HTTP/1.1 400 Bad Request
 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 533
ERROR - 2023-07-08 13:23:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 421
ERROR - 2023-07-08 13:40:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 421
ERROR - 2023-07-08 13:40:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 421
ERROR - 2023-07-08 13:52:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 421
ERROR - 2023-07-08 14:15:43 --> Query error: Unknown column 'tbl_vendor_kbli_sbu.id_kbli' in 'on clause' - Invalid query: SELECT *
FROM `tbl_vendor_kbli_sbu`
LEFT JOIN `tbl_kbli` ON `tbl_vendor_kbli_sbu`.`id_kbli` = `tbl_kbli`.`id_kbli`
LEFT JOIN `tbl_kualifikasi_izin` ON `tbl_vendor_kbli_sbu`.`id_kualifikasi_izin` = `tbl_kualifikasi_izin`.`id_kualifikasi_izin`
WHERE `tbl_vendor_kbli_sbu`.`id_vendor` = '1'
ORDER BY `tbl_vendor_kbli_sbu`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-07-08 14:15:51 --> Query error: Unknown column 'tbl_vendor_kbli_sbu.id_kbli' in 'on clause' - Invalid query: SELECT *
FROM `tbl_vendor_kbli_sbu`
LEFT JOIN `tbl_kbli` ON `tbl_vendor_kbli_sbu`.`id_kbli` = `tbl_kbli`.`id_kbli`
LEFT JOIN `tbl_kualifikasi_izin` ON `tbl_vendor_kbli_sbu`.`id_kualifikasi_izin` = `tbl_kualifikasi_izin`.`id_kualifikasi_izin`
WHERE `tbl_vendor_kbli_sbu`.`id_vendor` = '1'
ORDER BY `tbl_vendor_kbli_sbu`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-07-08 14:16:25 --> Query error: Unknown column 'tbl_vendor_kbli_sbu.id_kbli' in 'on clause' - Invalid query: SELECT *
FROM `tbl_vendor_kbli_sbu`
LEFT JOIN `tbl_kbli` ON `tbl_vendor_kbli_sbu`.`id_kbli` = `tbl_kbli`.`id_kbli`
LEFT JOIN `tbl_kualifikasi_izin` ON `tbl_vendor_kbli_sbu`.`id_kualifikasi_izin` = `tbl_kualifikasi_izin`.`id_kualifikasi_izin`
WHERE `tbl_vendor_kbli_sbu`.`id_vendor` = '1'
ORDER BY `tbl_vendor_kbli_sbu`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-07-08 14:18:01 --> Query error: Unknown column 'tbl_vendor_kbli_sbu.id_kualifikasi_izin' in 'on clause' - Invalid query: SELECT *
FROM `tbl_vendor_kbli_sbu`
LEFT JOIN `tbl_sbu` ON `tbl_vendor_kbli_sbu`.`id_sbu` = `tbl_sbu`.`id_sbu`
LEFT JOIN `tbl_kualifikasi_izin` ON `tbl_vendor_kbli_sbu`.`id_kualifikasi_izin` = `tbl_kualifikasi_izin`.`id_kualifikasi_izin`
WHERE `tbl_vendor_kbli_sbu`.`id_vendor` = '1'
ORDER BY `tbl_vendor_kbli_sbu`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-07-08 14:18:51 --> Query error: Unknown column 'tbl_kualifikasi_sbu.id_kualifikasi_sbu' in 'on clause' - Invalid query: SELECT *
FROM `tbl_vendor_kbli_sbu`
LEFT JOIN `tbl_sbu` ON `tbl_vendor_kbli_sbu`.`id_sbu` = `tbl_sbu`.`id_sbu`
LEFT JOIN `tbl_kualifikasi_izin` ON `tbl_vendor_kbli_sbu`.`id_kualifikasi_sbu` = `tbl_kualifikasi_sbu`.`id_kualifikasi_sbu`
WHERE `tbl_vendor_kbli_sbu`.`id_vendor` = '1'
ORDER BY `tbl_vendor_kbli_sbu`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-07-08 14:21:10 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 563
ERROR - 2023-07-08 14:21:10 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 564
ERROR - 2023-07-08 14:21:15 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 563
ERROR - 2023-07-08 14:21:15 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 564
ERROR - 2023-07-08 14:22:31 --> Query error: Unknown column 'alasan_validator' in 'field list' - Invalid query: UPDATE `tbl_vendor_kbli_sbu` SET `alasan_validator` = 'test', `sts_kbli_sbu` = 1, `nama_validator` = 'Test', `tgl_periksa` = '2023-07-08 14:22'
WHERE `id_url_kbli_sbu` = 'aa754bafed624c33b52335b976a16b2d'
ERROR - 2023-07-08 14:22:35 --> Query error: Unknown column 'alasan_validator' in 'field list' - Invalid query: UPDATE `tbl_vendor_kbli_sbu` SET `alasan_validator` = 'test', `sts_kbli_sbu` = 1, `nama_validator` = 'Test', `tgl_periksa` = '2023-07-08 14:22'
WHERE `id_url_kbli_sbu` = 'aa754bafed624c33b52335b976a16b2d'
ERROR - 2023-07-08 14:24:27 --> Query error: Unknown column 'alasan_validator' in 'field list' - Invalid query: UPDATE `tbl_vendor_sbu` SET `alasan_validator` = 'Tidaaaaaaaaaaaaak', `sts_validasi` = 2, `nama_validator` = 'Test', `tgl_periksa` = '2023-07-08 14:24'
WHERE `id_url` = '3df2e84504564b4e863a3e68674c912a'
ERROR - 2023-07-08 14:24:39 --> Query error: Unknown column 'alasan_validator' in 'field list' - Invalid query: UPDATE `tbl_vendor_sbu` SET `alasan_validator` = 'Tidaaaaaaaaaaaaak', `sts_validasi` = 2, `nama_validator` = 'Test', `tgl_periksa` = '2023-07-08 14:24'
WHERE `id_url` = '3df2e84504564b4e863a3e68674c912a'
ERROR - 2023-07-08 14:24:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 644
ERROR - 2023-07-08 14:24:43 --> Query error: Unknown column 'alasan_validator' in 'field list' - Invalid query: UPDATE `tbl_vendor_sbu` SET `alasan_validator` = NULL, `sts_validasi` = 2, `nama_validator` = 'Test', `tgl_periksa` = '2023-07-08 14:24'
WHERE `id_url` IS NULL
ERROR - 2023-07-08 14:25:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 644
ERROR - 2023-07-08 14:27:38 --> Severity: Warning --> readfile(http://localhost/vms-jmto/file_vms/PT TOWER INDONESIA/NIB-2023/company_profile_kintekindo.pdf): failed to open stream: HTTP request failed! HTTP/1.1 400 Bad Request
 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 756
ERROR - 2023-07-08 07:49:37 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:49:39 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:49:51 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:50:05 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:50:25 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:50:38 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:50:41 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:50:42 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:50:48 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:51:11 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:51:11 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:51:11 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:51:12 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:51:12 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:51:12 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:51:12 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:51:12 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:51:12 --> 404 Page Not Found: validator/Data_rekanan/data_rekanan.js
ERROR - 2023-07-08 07:57:03 --> 404 Page Not Found: Js_folder/data_rekanan.js
ERROR - 2023-07-08 14:58:46 --> Severity: error --> Exception: Too few arguments to function Rekanan_tervalidasi::encryption_siup(), 0 passed in C:\laragon\www\eproc-jmto\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 180
