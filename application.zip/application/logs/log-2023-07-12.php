<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-12 07:12:38 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-12 14:27:16 --> Severity: Notice --> Undefined index: kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 598
ERROR - 2023-07-12 14:27:20 --> Severity: Notice --> Undefined index: kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 598
ERROR - 2023-07-12 14:27:47 --> Severity: Notice --> Undefined index: kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 598
ERROR - 2023-07-12 14:31:39 --> Severity: Notice --> Undefined index: kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 626
ERROR - 2023-07-12 14:32:25 --> Severity: Notice --> Undefined index: kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 626
ERROR - 2023-07-12 14:45:14 --> Severity: Notice --> Undefined index: kode_sbu C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 819
ERROR - 2023-07-12 14:45:19 --> Severity: Notice --> Undefined index: kode_sbu C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 819
ERROR - 2023-07-12 14:45:59 --> Severity: Notice --> Undefined index: id_url C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 880
ERROR - 2023-07-12 14:45:59 --> Severity: Notice --> Undefined index: id_vendor_sbu C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 883
ERROR - 2023-07-12 14:46:59 --> Severity: Notice --> Undefined index: id_vendor_sbu C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 883
ERROR - 2023-07-12 15:44:17 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
ERROR - 2023-07-12 15:47:46 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
ERROR - 2023-07-12 15:51:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 254
ERROR - 2023-07-12 15:51:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 306
ERROR - 2023-07-12 15:51:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 307
ERROR - 2023-07-12 15:51:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 309
ERROR - 2023-07-12 15:51:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 310
ERROR - 2023-07-12 15:51:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 317
ERROR - 2023-07-12 15:51:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 319
ERROR - 2023-07-12 15:52:28 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
ERROR - 2023-07-12 15:53:26 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
ERROR - 2023-07-12 15:53:55 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
ERROR - 2023-07-12 15:54:08 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
ERROR - 2023-07-12 15:57:56 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
ERROR - 2023-07-12 15:58:10 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\laragon\www\eproc-jmto\system\libraries\Email.php 2269
ERROR - 2023-07-12 16:10:51 --> Severity: Notice --> Undefined variable: base_url C:\laragon\www\eproc-jmto\application\libraries\Email_send.php 54
ERROR - 2023-07-12 16:11:07 --> Severity: Notice --> Undefined variable: base_url C:\laragon\www\eproc-jmto\application\libraries\Email_send.php 54
ERROR - 2023-07-12 16:49:20 --> Severity: Notice --> Undefined index: nomor_surat C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 1548
ERROR - 2023-07-12 16:49:31 --> Severity: Notice --> Undefined index: nomor_surat C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 1548
ERROR - 2023-07-12 16:50:36 --> Query error: Unknown column 'no_surat' in 'field list' - Invalid query: INSERT INTO `monitoring_dokumen` (`id_vendor`, `id_url`, `jenis_dokumen`, `no_surat`, `id_dokumen`, `alasan_validator`, `sts_validasi`, `nama_validator`, `tgl_periksa`, `notifikasi`) VALUES ('1', '70ad6d71d0cc4320aee9c29c80c66975', 'AKTA-PENDIRIAN', '12412as', '19', 'tes', 2, 'Test', '2023-07-12 16:50', 1)
ERROR - 2023-07-12 16:58:35 --> Severity: Notice --> Undefined index: nomor_surat C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 1801
ERROR - 2023-07-12 16:58:54 --> Severity: Notice --> Undefined index: nomor_surat C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 1801
ERROR - 2023-07-12 17:01:59 --> Severity: Notice --> Undefined index: id_PENGURUS C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 1945
ERROR - 2023-07-12 17:11:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 254
ERROR - 2023-07-12 17:11:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 306
ERROR - 2023-07-12 17:11:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 307
ERROR - 2023-07-12 17:11:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 309
ERROR - 2023-07-12 17:11:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 310
ERROR - 2023-07-12 17:11:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 317
ERROR - 2023-07-12 17:11:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 319
ERROR - 2023-07-12 17:11:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\libraries\Email_send.php 22
ERROR - 2023-07-12 17:30:02 --> Severity: error --> Exception: Call to undefined method Email_send::sen_orw_email() C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 2421
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_jenis_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 48
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 52
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'nama_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 57
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'kualifikasi_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 59
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_upload_dokumen' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 61
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_dokumen_cek' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 68
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 76
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_jenis_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 48
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 52
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'nama_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 57
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'kualifikasi_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 59
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_upload_dokumen' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 61
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_dokumen_cek' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 68
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 76
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_jenis_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 48
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 52
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'nama_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 57
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'kualifikasi_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 59
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_upload_dokumen' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 61
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_dokumen_cek' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 68
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 76
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_jenis_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 48
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 52
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'nama_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 57
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'kualifikasi_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 59
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_upload_dokumen' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 61
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_dokumen_cek' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 68
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 76
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_jenis_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 48
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 52
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'nama_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 57
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'kualifikasi_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 59
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_upload_dokumen' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 61
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_dokumen_cek' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 68
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 76
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_jenis_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 48
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 52
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'nama_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 57
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'kualifikasi_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 59
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_upload_dokumen' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 61
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_dokumen_cek' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 68
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 76
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_jenis_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 48
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 52
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'nama_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 57
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'kualifikasi_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 59
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_upload_dokumen' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 61
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_dokumen_cek' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 68
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 76
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_jenis_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 48
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 52
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'nama_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 57
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'kualifikasi_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 59
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_upload_dokumen' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 61
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_dokumen_cek' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 68
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 76
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_jenis_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 48
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 52
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'nama_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 57
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'kualifikasi_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 59
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_upload_dokumen' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 61
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_dokumen_cek' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 68
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 76
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_jenis_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 48
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 52
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'nama_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 57
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'kualifikasi_usaha' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 59
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_upload_dokumen' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 61
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'sts_dokumen_cek' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 68
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 76
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:22:59 --> Severity: Notice --> Trying to get property 'id_url_vendor' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 77
ERROR - 2023-07-12 18:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:28:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:29:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:29:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:29:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:29:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:29:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:29:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:29:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:29:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:29:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 67
ERROR - 2023-07-12 18:52:51 --> Severity: error --> Exception: Call to undefined method M_Rekanan_tervalidasi::cek_vendor_tervalidasi() C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 47
ERROR - 2023-07-12 18:53:39 --> Severity: error --> Exception: Call to undefined method M_Rekanan_tervalidasi::cek_vendor_tervalidasi_siup() C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 47
ERROR - 2023-07-12 19:02:22 --> Query error: Unknown column 'sts_validasi' in 'field list' - Invalid query: SELECT `sts_validasi`
FROM `tbl_vendor_kbli_siup`
WHERE `sts_validasi` = 1
AND `id_vendor` = '1'
ERROR - 2023-07-12 19:03:19 --> Query error: Unknown column 'sts_validasi' in 'field list' - Invalid query: SELECT `sts_validasi`
FROM `tbl_vendor_kbli_siup`
WHERE `sts_kbli_siup` = 1
AND `id_vendor` = '1'
ERROR - 2023-07-12 19:03:58 --> Query error: Unknown column 'sts_validasi_kbli' in 'field list' - Invalid query: SELECT `sts_validasi_kbli`
FROM `tbl_vendor_kbli_siup`
WHERE `sts_kbli_siup` = 1
AND `id_vendor` = '1'
ERROR - 2023-07-12 19:04:28 --> Severity: error --> Exception: Unsupported operand types C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 55
ERROR - 2023-07-12 19:07:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 55
ERROR - 2023-07-12 19:07:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 55
ERROR - 2023-07-12 19:07:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 55
ERROR - 2023-07-12 19:08:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 55
ERROR - 2023-07-12 19:09:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 2992
ERROR - 2023-07-12 19:09:39 --> Severity: Warning --> readfile(http://localhost/vms-jmto/file_vms//Neraca-2023/format_capex3.xlsx): failed to open stream: HTTP request failed! HTTP/1.1 404 Not Found
 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 3000
ERROR - 2023-07-12 19:11:45 --> Severity: Notice --> Trying to access array offset on value of type int C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 55
ERROR - 2023-07-12 19:11:45 --> Severity: Notice --> Trying to access array offset on value of type int C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 55
ERROR - 2023-07-12 19:11:45 --> Severity: Notice --> Trying to access array offset on value of type int C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 55
ERROR - 2023-07-12 19:16:11 --> Severity: error --> Exception: Unsupported operand types C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 55
ERROR - 2023-07-12 20:03:58 --> Severity: error --> Exception: Call to undefined method M_Rekanan_tervalidasi::cek_vendor_tdk_valid_siup() C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 79
ERROR - 2023-07-12 20:49:15 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_result() C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 1370
ERROR - 2023-07-12 20:49:38 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_results() C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 1370
ERROR - 2023-07-12 20:52:58 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::num_rows() C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 1371
ERROR - 2023-07-12 14:05:36 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 153
ERROR - 2023-07-12 21:12:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 32
ERROR - 2023-07-12 21:13:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 32
ERROR - 2023-07-12 14:14:03 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-12 14:27:49 --> 404 Page Not Found: Js_folder/data_rekaan.min.js
ERROR - 2023-07-12 21:47:36 --> 404 Page Not Found: validator/Rekanan_terundang/index
ERROR - 2023-07-12 21:49:36 --> Severity: Notice --> Undefined variable: vendor C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\rekanan_tervalidasi.php 28
ERROR - 2023-07-12 21:49:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\rekanan_tervalidasi.php 28
ERROR - 2023-07-12 21:49:36 --> Severity: Notice --> Undefined variable: vendor C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\rekanan_tervalidasi.php 34
ERROR - 2023-07-12 21:49:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\rekanan_tervalidasi.php 34
ERROR - 2023-07-12 21:49:36 --> Severity: Notice --> Undefined variable: nama_izin_usaha C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\rekanan_tervalidasi.php 43
ERROR - 2023-07-12 21:49:36 --> Severity: Notice --> Undefined variable: vendor C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\rekanan_tervalidasi.php 52
ERROR - 2023-07-12 21:49:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\rekanan_tervalidasi.php 52
ERROR - 2023-07-12 21:49:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 216
ERROR - 2023-07-12 21:49:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 217
ERROR - 2023-07-12 21:49:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 218
ERROR - 2023-07-12 21:49:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 219
ERROR - 2023-07-12 21:49:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 220
ERROR - 2023-07-12 21:49:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 221
ERROR - 2023-07-12 21:49:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 222
ERROR - 2023-07-12 21:49:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 223
ERROR - 2023-07-12 21:49:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 224
ERROR - 2023-07-12 21:49:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 225
ERROR - 2023-07-12 21:49:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 226
ERROR - 2023-07-12 21:49:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 227
ERROR - 2023-07-12 21:49:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 228
ERROR - 2023-07-12 21:49:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 229
ERROR - 2023-07-12 14:58:51 --> 404 Page Not Found: Js_folder/data_rekaan.min.js
ERROR - 2023-07-12 14:58:59 --> 404 Page Not Found: Js_folder/data_rekaan.min.js
