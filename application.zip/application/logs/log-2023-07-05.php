<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-05 14:45:40 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-05 21:45:52 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\eproc-jmto\application\libraries\Role_login.php 21
ERROR - 2023-07-05 22:02:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-05 22:02:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 31
ERROR - 2023-07-05 22:02:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:02:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:02:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-05 22:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 31
ERROR - 2023-07-05 22:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:03:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-05 22:03:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 31
ERROR - 2023-07-05 22:03:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:03:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:03:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:03:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 129
ERROR - 2023-07-05 22:03:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-05 22:03:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 31
ERROR - 2023-07-05 22:03:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:03:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:03:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:03:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-05 22:03:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 31
ERROR - 2023-07-05 22:03:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:03:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:03:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:03:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-05 22:03:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 31
ERROR - 2023-07-05 22:03:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:03:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:03:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:03:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 129
ERROR - 2023-07-05 22:04:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-05 22:04:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 31
ERROR - 2023-07-05 22:04:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:04:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:04:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:04:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-05 22:04:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 31
ERROR - 2023-07-05 22:04:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:04:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:04:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:06:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-05 22:06:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 30
ERROR - 2023-07-05 22:06:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:06:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:06:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:06:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-05 22:06:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 30
ERROR - 2023-07-05 22:06:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:06:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:06:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:06:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-05 22:06:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 30
ERROR - 2023-07-05 22:06:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:06:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:06:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:06:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-05 22:06:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 30
ERROR - 2023-07-05 22:06:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:06:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:06:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:07:45 --> Severity: Notice --> Undefined variable: nama_izin_usaha C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 46
ERROR - 2023-07-05 22:07:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:07:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:07:46 --> Severity: Notice --> Undefined variable: nama_izin_usaha C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 46
ERROR - 2023-07-05 22:07:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:07:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:07:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:07:52 --> Severity: Notice --> Undefined variable: nama_izin_usaha C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 46
ERROR - 2023-07-05 22:07:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:07:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 128
ERROR - 2023-07-05 22:08:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-05 22:08:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 30
ERROR - 2023-07-05 22:08:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:08:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:08:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:08:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-05 22:08:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 30
ERROR - 2023-07-05 22:08:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-05 22:08:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-05 22:08:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-05 22:08:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 128
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:08:47 --> Severity: Warning --> Use of undefined constant id_vendor - assumed 'id_vendor' (this will throw an Error in a future version of PHP) C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 165
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:09:36 --> Severity: Warning --> Use of undefined constant id_vendor - assumed 'id_vendor' (this will throw an Error in a future version of PHP) C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 165
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: length C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 49
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: length C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 50
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: start C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 50
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: start C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 143
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: draw C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 163
ERROR - 2023-07-05 22:10:50 --> Severity: Warning --> Use of undefined constant id_vendor - assumed 'id_vendor' (this will throw an Error in a future version of PHP) C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 165
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:10:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 20
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$kode_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 147
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kbli C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 148
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$nama_kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 149
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:23 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$sts_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:11:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_kbli_siup C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 158
ERROR - 2023-07-05 22:13:03 --> Severity: error --> Exception: Too few arguments to function M_Rekanan_tervalidasi::_get_data_query_kbli_siup(), 0 passed in C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php on line 189 and exactly 1 expected C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 151
ERROR - 2023-07-05 22:13:22 --> Query error: Unknown column 'tbl_vendor.id_vendor' in 'order clause' - Invalid query: SELECT *
FROM `tbl_vendor_kbli_siup`
LEFT JOIN `tbl_kbli` ON `tbl_vendor_kbli_siup`.`id_kbli` = `tbl_kbli`.`id_kbli`
LEFT JOIN `tbl_kualifikasi_izin` ON `tbl_vendor_kbli_siup`.`id_kualifikasi_izin` = `tbl_kualifikasi_izin`.`id_kualifikasi_izin`
WHERE `tbl_vendor_kbli_siup`.`id_vendor` = '1'
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-07-05 22:52:37 --> Query error: Unknown column 'sts_kbli_siup' in 'field list' - Invalid query: UPDATE `tbl_vendor_siup` SET `alasan_validator` = 'Tidak valid no kbli masih salah', `sts_kbli_siup` = 2
WHERE `id_url` = '21411c8e3bff4608b36b0819b66eb6cd'
ERROR - 2023-07-05 22:53:11 --> Query error: Unknown column 'id_url_kbli_siup' in 'where clause' - Invalid query: UPDATE `tbl_vendor_siup` SET `alasan_validator` = 'Tidak valid no kbli masih salah', `sts_kbli_siup` = 2
WHERE `id_url_kbli_siup` = '21411c8e3bff4608b36b0819b66eb6cd'
ERROR - 2023-07-05 22:53:18 --> Query error: Unknown column 'id_url_kbli_siup' in 'where clause' - Invalid query: UPDATE `tbl_vendor_siup` SET `alasan_validator` = 'salah', `sts_kbli_siup` = 2
WHERE `id_url_kbli_siup` = '21411c8e3bff4608b36b0819b66eb6cd'
ERROR - 2023-07-05 23:10:26 --> Severity: Warning --> readfile(http://localhost/vms-jmto/file_vms/PT TOWER INDONESIA/SIUP-2023/tahap_1.pdf): failed to open stream: HTTP request failed! HTTP/1.1 400 Bad Request
 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 337
