<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-09 13:47:50 --> 404 Page Not Found: Images/bg
