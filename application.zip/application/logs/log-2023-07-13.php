<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-13 16:17:45 --> Severity: Notice --> Undefined property: Rekanan_tervalidasi::$ci C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 36
ERROR - 2023-07-13 16:17:45 --> Severity: Notice --> Trying to get property 'M_Rekanan_tervalidasi' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 36
ERROR - 2023-07-13 16:17:45 --> Severity: error --> Exception: Call to a member function get_id_vendor() on null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 36
ERROR - 2023-07-13 16:18:15 --> Severity: Notice --> Undefined variable: data C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 36
ERROR - 2023-07-13 16:18:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 38
ERROR - 2023-07-13 16:19:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 38
ERROR - 2023-07-13 16:19:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 38
ERROR - 2023-07-13 16:20:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 38
ERROR - 2023-07-13 16:22:51 --> Severity: Notice --> Undefined property: Rekanan_tervalidasi::$ci C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 36
ERROR - 2023-07-13 16:22:51 --> Severity: Notice --> Trying to get property 'M_Rekanan_tervalidasi' of non-object C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 36
ERROR - 2023-07-13 16:22:51 --> Severity: error --> Exception: Call to a member function get_row_vendor() on null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 36
ERROR - 2023-07-13 09:56:56 --> 404 Page Not Found: validator/Undefined466441935514409a8f648d2412cc0f25/index
ERROR - 2023-07-13 09:57:19 --> 404 Page Not Found: validator/Undefined466441935514409a8f648d2412cc0f25/index
ERROR - 2023-07-13 09:57:26 --> 404 Page Not Found: validator/Undefined466441935514409a8f648d2412cc0f25/index
ERROR - 2023-07-13 09:57:32 --> 404 Page Not Found: validator/Undefined466441935514409a8f648d2412cc0f25/index
ERROR - 2023-07-13 09:57:52 --> 404 Page Not Found: validator/Undefined466441935514409a8f648d2412cc0f25/index
ERROR - 2023-07-13 17:15:11 --> Severity: Notice --> Undefined property: Rekanan_tervalidasi::$M_Rekanan_terundang C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 45
ERROR - 2023-07-13 17:15:11 --> Severity: error --> Exception: Call to a member function update_vendor() on null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 45
ERROR - 2023-07-13 17:15:25 --> Severity: Notice --> Undefined property: Rekanan_tervalidasi::$M_Rekanan_terundang C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 45
ERROR - 2023-07-13 17:15:25 --> Severity: error --> Exception: Call to a member function update_vendor() on null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 45
ERROR - 2023-07-13 17:15:53 --> Severity: Notice --> Undefined property: Rekanan_tervalidasi::$M_Rekanan_terundang C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 45
ERROR - 2023-07-13 17:15:53 --> Severity: error --> Exception: Call to a member function update_vendor() on null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 45
ERROR - 2023-07-13 17:17:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 49
ERROR - 2023-07-13 17:17:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\libraries\Email_send.php 24
ERROR - 2023-07-13 17:18:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 49
ERROR - 2023-07-13 17:18:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\libraries\Email_send.php 24
ERROR - 2023-07-13 10:25:43 --> 404 Page Not Found: Images/bg
