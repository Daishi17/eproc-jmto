<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-03 00:49:19 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\eproc-jmto\application\libraries\Role_login.php 21
ERROR - 2023-07-03 00:55:36 --> Severity: Notice --> Undefined property: CI_Loader::$jam_tgl C:\laragon\www\eproc-jmto\application\views\template_new\header.php 27
ERROR - 2023-07-03 00:55:36 --> Severity: error --> Exception: Call to a member function tgl_indo() on null C:\laragon\www\eproc-jmto\application\views\template_new\header.php 27
ERROR - 2023-07-03 00:55:41 --> Severity: Notice --> Undefined property: CI_Loader::$jam_tgl C:\laragon\www\eproc-jmto\application\views\template_new\header.php 27
ERROR - 2023-07-03 00:55:41 --> Severity: error --> Exception: Call to a member function tgl_indo() on null C:\laragon\www\eproc-jmto\application\views\template_new\header.php 27
ERROR - 2023-07-03 00:55:43 --> Severity: Notice --> Undefined property: CI_Loader::$jam_tgl C:\laragon\www\eproc-jmto\application\views\template_new\header.php 27
ERROR - 2023-07-03 00:55:43 --> Severity: error --> Exception: Call to a member function tgl_indo() on null C:\laragon\www\eproc-jmto\application\views\template_new\header.php 27
ERROR - 2023-07-03 06:29:42 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:29:42 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:29:42 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:29:42 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:29:42 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:29:42 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:29:42 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:29:42 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:29:42 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:29:42 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:29:42 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:29:42 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-03 06:30:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:30:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:30:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:30:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:30:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:30:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:30:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:30:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:30:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:30:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:30:18 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:30:19 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-03 06:30:21 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 06:35:19 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-03 20:54:50 --> 404 Page Not Found: Test/index
ERROR - 2023-07-03 20:54:56 --> 404 Page Not Found: Test/index
ERROR - 2023-07-03 20:55:03 --> 404 Page Not Found: Test/index
ERROR - 2023-07-03 20:55:07 --> 404 Page Not Found: Test/index
ERROR - 2023-07-03 21:58:10 --> 404 Page Not Found: validator/Undefined3f88a8f6025e4e1e871ad52fc434a846/index
ERROR - 2023-07-03 21:58:13 --> 404 Page Not Found: validator/Undefined3f88a8f6025e4e1e871ad52fc434a846/index
