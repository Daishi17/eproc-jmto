<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-04 03:40:02 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\eproc-jmto\application\libraries\Role_login.php 21
ERROR - 2023-07-04 04:03:15 --> 404 Page Not Found: validator/Rekanan_baru/get_rekanan_baru
ERROR - 2023-07-04 04:03:27 --> Severity: Notice --> Undefined property: Rekanan_baru::$M_datapenyedia C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 18
ERROR - 2023-07-04 04:03:27 --> Severity: error --> Exception: Call to a member function get_rekanan_baru() on null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 18
ERROR - 2023-07-04 04:14:31 --> Severity: Notice --> Undefined property: Rekanan_baru::$M_datapenyedia C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 18
ERROR - 2023-07-04 04:14:31 --> Severity: error --> Exception: Call to a member function get_rekanan_baru() on null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 18
ERROR - 2023-07-04 04:15:34 --> Severity: error --> Exception: Call to undefined method M_Rekanan_baru::get_rekanan_baru() C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 24
ERROR - 2023-07-04 04:15:47 --> Severity: Notice --> Undefined property: stdClass::$jenis_usaha C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 31
ERROR - 2023-07-04 04:20:32 --> Severity: Warning --> explode(): Empty delimiter C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 33
ERROR - 2023-07-04 04:20:47 --> Severity: Warning --> explode(): Empty delimiter C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 33
ERROR - 2023-07-04 04:20:52 --> Severity: Warning --> explode(): Empty delimiter C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 33
ERROR - 2023-07-04 04:26:59 --> Query error: Unknown column 'jenis_usaha' in 'order clause' - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` IS NULL
ORDER BY `jenis_usaha` ASC
 LIMIT 10
ERROR - 2023-07-04 04:29:19 --> Severity: Notice --> Array to string conversion C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 32
ERROR - 2023-07-04 04:29:19 --> Severity: Notice --> Array to string conversion C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 32
ERROR - 2023-07-04 04:30:50 --> Severity: Notice --> Undefined index: nama_izin_usaha C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 36
ERROR - 2023-07-04 04:30:55 --> Severity: Notice --> Undefined index: nama_izin_usaha C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 36
ERROR - 2023-07-04 04:31:36 --> Severity: Notice --> Undefined offset: 2 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 36
ERROR - 2023-07-04 04:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 36
ERROR - 2023-07-04 04:31:38 --> Severity: Notice --> Undefined offset: 2 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 36
ERROR - 2023-07-04 04:31:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 36
ERROR - 2023-07-04 04:31:46 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 36
ERROR - 2023-07-04 04:31:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 36
ERROR - 2023-07-04 04:32:25 --> Severity: Notice --> Undefined variable: kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 34
ERROR - 2023-07-04 04:32:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 34
ERROR - 2023-07-04 04:32:25 --> Severity: Notice --> Undefined variable: kualifikasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 34
ERROR - 2023-07-04 04:32:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 34
ERROR - 2023-07-04 04:40:52 --> Severity: Notice --> Array to string conversion C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 37
ERROR - 2023-07-04 04:40:52 --> Severity: Notice --> Array to string conversion C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 37
ERROR - 2023-07-04 04:42:14 --> Severity: Notice --> Undefined index: nama_jenis_izin C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 32
ERROR - 2023-07-04 04:42:14 --> Severity: Notice --> Undefined index: nama_jenis_izin C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 32
ERROR - 2023-07-04 05:09:55 --> Severity: Warning --> Use of undefined constant id_jenis_usaha - assumed 'id_jenis_usaha' (this will throw an Error in a future version of PHP) C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_baru.php 62
ERROR - 2023-07-04 05:39:12 --> Query error: Unknown column 'jenis_usaha' in 'order clause' - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` IS NULL
ORDER BY `jenis_usaha` ASC
 LIMIT 10
ERROR - 2023-07-04 05:39:36 --> Query error: Unknown column 'sts_aktif' in 'field list' - Invalid query: UPDATE `tbl_vendor_npwp` SET `sts_aktif` = 1
ERROR - 2023-07-04 05:39:41 --> Query error: Unknown column 'sts_aktif' in 'field list' - Invalid query: UPDATE `tbl_vendor_npwp` SET `sts_aktif` = 1
ERROR - 2023-07-04 05:34:19 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-04 08:03:12 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-04 15:09:23 --> Severity: Notice --> Undefined property: Rekanan_tervalidasi::$M_rekanan_tervalidasi C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 23
ERROR - 2023-07-04 15:09:23 --> Severity: error --> Exception: Call to a member function gettable_rekanan_tervalidasi() on null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 23
ERROR - 2023-07-04 15:10:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\eproc-jmto\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-07-04 15:10:32 --> Unable to connect to the database
ERROR - 2023-07-04 15:10:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\eproc-jmto\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-07-04 15:10:34 --> Unable to connect to the database
ERROR - 2023-07-04 15:10:44 --> Severity: error --> Exception: Call to undefined method M_Rekanan_tervalidasi::gettable_rekanan_tervalidasi() C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 23
ERROR - 2023-07-04 15:10:57 --> Severity: error --> Exception: Call to undefined method M_Rekanan_tervalidasi::gettable_rekanan_tervalidasi() C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 23
ERROR - 2023-07-04 15:14:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 59
ERROR - 2023-07-04 15:14:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 63
ERROR - 2023-07-04 16:10:25 --> 404 Page Not Found: validator/Rekanan_tervalidasi/466441935514409a8f648d2412cc0f25
ERROR - 2023-07-04 16:10:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 69
ERROR - 2023-07-04 16:10:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 73
ERROR - 2023-07-04 16:18:00 --> Severity: Compile Error --> Cannot redeclare M_Rekanan_tervalidasi::get_row_vendor() C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 104
ERROR - 2023-07-04 16:18:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 36
ERROR - 2023-07-04 16:19:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 36
ERROR - 2023-07-04 16:20:09 --> Severity: Notice --> Undefined index: row_vendor C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 24
ERROR - 2023-07-04 16:20:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 24
ERROR - 2023-07-04 16:20:09 --> Severity: Notice --> Undefined property: CI_Loader::$M_dashboard C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 46
ERROR - 2023-07-04 16:20:09 --> Severity: error --> Exception: Call to a member function get_kualifikasi_izin() on null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 46
ERROR - 2023-07-04 16:20:17 --> Severity: Notice --> Undefined property: CI_Loader::$M_dashboard C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 46
ERROR - 2023-07-04 16:20:17 --> Severity: error --> Exception: Call to a member function get_kualifikasi_izin() on null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 46
ERROR - 2023-07-04 16:22:23 --> Severity: Notice --> Array to string conversion C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 24
ERROR - 2023-07-04 16:22:23 --> Severity: Notice --> Undefined variable: Array C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 24
ERROR - 2023-07-04 16:22:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 24
ERROR - 2023-07-04 16:22:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 24
ERROR - 2023-07-04 16:22:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 28
ERROR - 2023-07-04 16:22:40 --> Severity: Notice --> Array to string conversion C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 24
ERROR - 2023-07-04 16:22:40 --> Severity: Notice --> Undefined variable: Array C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 24
ERROR - 2023-07-04 16:22:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 24
ERROR - 2023-07-04 16:22:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 24
ERROR - 2023-07-04 16:22:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 28
ERROR - 2023-07-04 09:49:23 --> 404 Page Not Found: Rekanan_tervalidasi/get_dokumen_vendor
ERROR - 2023-07-04 09:49:27 --> 404 Page Not Found: Rekanan_tervalidasi/get_dokumen_vendor
ERROR - 2023-07-04 09:49:31 --> 404 Page Not Found: Rekanan_tervalidasi/get_dokumen_vendor
ERROR - 2023-07-04 09:55:04 --> 404 Page Not Found: Rekanan_tervalidasi/get_dokumen_vendor
ERROR - 2023-07-04 09:55:07 --> 404 Page Not Found: Rekanan_tervalidasi/get_dokumen_vendor
ERROR - 2023-07-04 09:55:23 --> 404 Page Not Found: Rekanan_tervalidasi/get_dokumen_vendor
ERROR - 2023-07-04 16:56:58 --> Severity: error --> Exception: Call to undefined method M_Rekanan_tervalidasi::get_row_siup() C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 123
ERROR - 2023-07-04 16:57:08 --> Severity: Notice --> Array to string conversion C:\laragon\www\eproc-jmto\system\database\DB_query_builder.php 2443
ERROR - 2023-07-04 16:57:08 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor_siup`
WHERE `tbl_vendor_siup`.`id_vendor` = Array
ERROR - 2023-07-04 17:29:59 --> Severity: error --> Exception: Object of class CI_Loader could not be converted to string C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 692
ERROR - 2023-07-04 10:29:59 --> 404 Page Not Found: Assets34543543/img
ERROR - 2023-07-04 17:30:35 --> Severity: error --> Exception: Object of class CI_Loader could not be converted to string C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 692
ERROR - 2023-07-04 10:30:48 --> 404 Page Not Found: Assets34543543/img
ERROR - 2023-07-04 10:33:09 --> 404 Page Not Found: Assets34543543/img
ERROR - 2023-07-04 10:33:22 --> 404 Page Not Found: Assets34543543/img
ERROR - 2023-07-04 10:34:02 --> 404 Page Not Found: Assets34543543/img
ERROR - 2023-07-04 10:34:27 --> 404 Page Not Found: Assets34543543/img
ERROR - 2023-07-04 10:44:21 --> 404 Page Not Found: Assets34543543/img
ERROR - 2023-07-04 11:01:49 --> 404 Page Not Found: Assets34543543/img
ERROR - 2023-07-04 11:01:53 --> 404 Page Not Found: Assets34543543/img
ERROR - 2023-07-04 12:46:12 --> 404 Page Not Found: Assets34543543/img
ERROR - 2023-07-04 12:47:11 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-04 12:47:12 --> 404 Page Not Found: Assets3/img
ERROR - 2023-07-04 12:47:20 --> 404 Page Not Found: Assets/img
ERROR - 2023-07-04 20:07:27 --> Severity: error --> Exception: Call to undefined method M_Rekanan_tervalidasi::update_enkrip_siup() C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 172
ERROR - 2023-07-04 20:07:33 --> Severity: error --> Exception: Call to undefined method M_Rekanan_tervalidasi::update_enkrip_siup() C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 172
ERROR - 2023-07-04 20:35:37 --> 404 Page Not Found: validator/Rekanan_tervalidasi/url_download_siupa1c7c3c35cb047ed87a8533bbe126a52
ERROR - 2023-07-04 20:35:54 --> 404 Page Not Found: validator/Rekanan_tervalidasi/url_download_siupa1c7c3c35cb047ed87a8533bbe126a52
ERROR - 2023-07-04 20:38:09 --> 404 Page Not Found: validator/Rekanan_tervalidasi/url_download_siupa1c7c3c35cb047ed87a8533bbe126a52
ERROR - 2023-07-04 20:38:26 --> 404 Page Not Found: validator/Rekanan_tervalidasi/url_download_siupa1c7c3c35cb047ed87a8533bbe126a52
ERROR - 2023-07-04 20:49:09 --> 404 Page Not Found: validator/Rekanan_tervalidasi/url_download_siupa1c7c3c35cb047ed87a8533bbe126a52
ERROR - 2023-07-04 20:49:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 186
ERROR - 2023-07-04 20:49:21 --> Severity: Warning --> file_get_contents(http://localhost/vms-jmto//SIUP-2023/tahap_1.pdf): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 189
ERROR - 2023-07-04 20:49:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 186
ERROR - 2023-07-04 20:49:51 --> Severity: Warning --> file_get_contents(http://localhost/vms-jmto/file_vms//SIUP-2023/tahap_1.pdf): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 189
ERROR - 2023-07-04 20:50:12 --> Severity: error --> Exception: Call to undefined function force_download() C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 187
ERROR - 2023-07-04 20:50:33 --> Severity: error --> Exception: Call to undefined function force_download() C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 185
ERROR - 2023-07-04 20:51:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 186
ERROR - 2023-07-04 20:53:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 187
ERROR - 2023-07-04 20:53:59 --> Severity: Warning --> file_get_contents(http://localhost/vms-jmto/file_vms//SIUP-2023/tahap_1.pdf): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 194
ERROR - 2023-07-04 20:55:00 --> Query error: Unknown column 'tbl_vendor.id_url' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`id_url` = '466441935514409a8f648d2412cc0f25'
ERROR - 2023-07-04 20:55:00 --> Query error: Unknown column 'tbl_vendor.id_url' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`id_url` = '466441935514409a8f648d2412cc0f25'
ERROR - 2023-07-04 20:55:13 --> Severity: Warning --> file_get_contents(http://localhost/vms-jmto/file_vms/PT TOWER INDONESIA/SIUP-2023/tahap_1.pdf): failed to open stream: HTTP request failed! HTTP/1.1 400 Bad Request
 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 194
ERROR - 2023-07-04 20:55:48 --> Severity: Warning --> fopen() expects at least 2 parameters, 1 given C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 189
ERROR - 2023-07-04 13:57:51 --> Severity: error --> Exception: syntax error, unexpected '}' C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 200
ERROR - 2023-07-04 20:57:58 --> Severity: Warning --> file_get_contents(http://localhost/vms-jmto/file_vms/PT TOWER INDONESIA/SIUP-2023/tahap_1.pdf): failed to open stream: HTTP request failed! HTTP/1.1 400 Bad Request
 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 191
ERROR - 2023-07-04 21:00:12 --> Severity: Warning --> file_get_contents(http://localhost/vms-jmto/file_vms/PT TOWER INDONESIA/SIUP-2023/tahap_1.pdf): failed to open stream: HTTP request failed! HTTP/1.1 400 Bad Request
 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 191
ERROR - 2023-07-04 21:03:35 --> Severity: Warning --> readfile(http://localhost/vms-jmto/file_vms/PT TOWER INDONESIA/SIUP-2023/tahap_1.pdf): failed to open stream: HTTP request failed! HTTP/1.1 400 Bad Request
 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 199
ERROR - 2023-07-04 21:30:15 --> Severity: error --> Exception: Too few arguments to function Rekanan_tervalidasi::cek_dokumen(), 0 passed in C:\laragon\www\eproc-jmto\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 24
ERROR - 2023-07-04 22:16:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '6 = ''
WHERE `id_vendor` = '1'
AND `id_url` = 'a1c7c3c35cb047ed87a8533bbe126a52'' at line 1 - Invalid query: UPDATE `tbl_vendor_siup` SET 6 = ''
WHERE `id_vendor` = '1'
AND `id_url` = 'a1c7c3c35cb047ed87a8533bbe126a52'
ERROR - 2023-07-04 22:16:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0 = ''
WHERE `id_vendor` = '1'
AND `id_url` = 'a1c7c3c35cb047ed87a8533bbe126a52'' at line 1 - Invalid query: UPDATE `tbl_vendor_siup` SET 0 = ''
WHERE `id_vendor` = '1'
AND `id_url` = 'a1c7c3c35cb047ed87a8533bbe126a52'
ERROR - 2023-07-04 22:16:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 182
ERROR - 2023-07-04 22:16:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '9 = ''
WHERE `id_vendor` IS NULL
AND `id_url` IS NULL' at line 1 - Invalid query: UPDATE `tbl_vendor_siup` SET 9 = ''
WHERE `id_vendor` IS NULL
AND `id_url` IS NULL
ERROR - 2023-07-04 22:17:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 182
ERROR - 2023-07-04 22:17:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0 = ''
WHERE `id_vendor` IS NULL
AND id
				_url' at line 1 - Invalid query: UPDATE `tbl_vendor_siup` SET 0 = ''
WHERE `id_vendor` IS NULL
AND id
				_url
ERROR - 2023-07-04 22:17:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '9 = ''
WHERE `id_vendor` = '1'
AND `id_url` = 'a1c7c3c35cb047ed87a8533bbe126a52'' at line 1 - Invalid query: UPDATE `tbl_vendor_siup` SET 9 = ''
WHERE `id_vendor` = '1'
AND `id_url` = 'a1c7c3c35cb047ed87a8533bbe126a52'
ERROR - 2023-07-04 22:18:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0 = ''
WHERE `id_vendor` = '1'
AND `id_url` = 'a1c7c3c35cb047ed87a8533bbe126a52'' at line 1 - Invalid query: UPDATE `tbl_vendor_siup` SET 0 = ''
WHERE `id_vendor` = '1'
AND `id_url` = 'a1c7c3c35cb047ed87a8533bbe126a52'
