<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-06 04:27:18 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-06 13:12:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-06 13:12:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 30
ERROR - 2023-07-06 13:12:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-06 13:12:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-06 13:12:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-06 13:12:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 128
ERROR - 2023-07-06 13:12:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 129
ERROR - 2023-07-06 13:12:59 --> Severity: Warning --> readfile(http://localhost/vms-jmto/file_vms/PT TOWER INDONESIA/SIUP-2023/tahap_1.pdf): failed to open stream: HTTP request failed! HTTP/1.1 400 Bad Request
 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 335
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: length C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 205
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: length C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 206
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: start C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 206
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: start C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 143
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: draw C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 163
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: length C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 205
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: length C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 206
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: start C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 206
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: start C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 143
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: draw C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 163
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Undefined index: search C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:17:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\models\M_datapenyedia\M_Rekanan_tervalidasi.php 176
ERROR - 2023-07-06 13:19:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-06 13:19:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 30
ERROR - 2023-07-06 13:19:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-06 13:19:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-06 13:19:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-06 13:19:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 128
ERROR - 2023-07-06 13:19:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 129
ERROR - 2023-07-06 13:20:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 27
ERROR - 2023-07-06 13:20:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 30
ERROR - 2023-07-06 13:20:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 31
ERROR - 2023-07-06 13:20:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 37
ERROR - 2023-07-06 13:20:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\views\validator\data_rekanan\cek_dokumen.php 55
ERROR - 2023-07-06 13:20:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 128
ERROR - 2023-07-06 13:20:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 129
ERROR - 2023-07-06 13:21:06 --> Severity: Warning --> readfile(http://localhost/vms-jmto/file_vms/PT TOWER INDONESIA/NIB-2023/ALUR_PROSES_E-CATALOG_JMTM_(1)1.pdf): failed to open stream: HTTP request failed! HTTP/1.1 400 Bad Request
 C:\laragon\www\eproc-jmto\application\controllers\validator\Rekanan_tervalidasi.php 534
ERROR - 2023-07-06 09:43:12 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-06 09:43:38 --> 404 Page Not Found: Images/bg
ERROR - 2023-07-06 16:48:25 --> Query error: Unknown column 'jenis_usaha' in 'order clause' - Invalid query: SELECT *
FROM `tbl_vendor`
LEFT JOIN `tbl_provinsi` ON `tbl_vendor`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kecamatan` ON `tbl_vendor`.`id_kecamatan` = `tbl_kecamatan`.`id_kecamatan`
LEFT JOIN `tbl_kabupaten` ON `tbl_vendor`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
WHERE `tbl_vendor`.`sts_aktif` = 1
ORDER BY `jenis_usaha` ASC
 LIMIT 10
ERROR - 2023-07-06 14:23:06 --> 404 Page Not Found: validator/Get_data_kbli/index
ERROR - 2023-07-06 21:23:26 --> Query error: Unknown column 'tbl_vendor.id_vendor' in 'order clause' - Invalid query: SELECT *
FROM `tbl_kbli`
ORDER BY `tbl_vendor`.`id_vendor` ASC
 LIMIT 10
ERROR - 2023-07-06 21:56:10 --> Severity: Notice --> Undefined variable: response C:\laragon\www\eproc-jmto\application\controllers\validator\Data_kbli.php 70
ERROR - 2023-07-06 21:56:14 --> Severity: Notice --> Undefined variable: response C:\laragon\www\eproc-jmto\application\controllers\validator\Data_kbli.php 70
ERROR - 2023-07-06 21:57:03 --> Severity: Notice --> Undefined variable: response C:\laragon\www\eproc-jmto\application\controllers\validator\Data_kbli.php 70
ERROR - 2023-07-06 21:57:27 --> Severity: Notice --> Undefined variable: response C:\laragon\www\eproc-jmto\application\controllers\validator\Data_kbli.php 70
ERROR - 2023-07-06 22:07:25 --> Severity: Notice --> Undefined variable: response C:\laragon\www\eproc-jmto\application\controllers\validator\Data_kbli.php 64
ERROR - 2023-07-06 22:07:30 --> Severity: Notice --> Undefined variable: response C:\laragon\www\eproc-jmto\application\controllers\validator\Data_kbli.php 64
ERROR - 2023-07-06 22:21:33 --> 404 Page Not Found: validator/Data_kbli/url_get_row
ERROR - 2023-07-06 22:21:34 --> 404 Page Not Found: validator/Data_kbli/url_get_row
ERROR - 2023-07-06 22:21:43 --> 404 Page Not Found: validator/Data_kbli/url_get_row
ERROR - 2023-07-06 22:21:48 --> 404 Page Not Found: validator/Data_kbli/url_get_row
ERROR - 2023-07-06 22:22:08 --> 404 Page Not Found: validator/Data_kbli/url_get_row
ERROR - 2023-07-06 23:18:54 --> Severity: Notice --> Undefined property: Data_sbu::$M_master C:\laragon\www\eproc-jmto\application\controllers\validator\Data_sbu.php 17
ERROR - 2023-07-06 23:18:54 --> Severity: error --> Exception: Call to a member function gettable_sbu() on null C:\laragon\www\eproc-jmto\application\controllers\validator\Data_sbu.php 17
ERROR - 2023-07-06 23:57:51 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=2596 C:\laragon\www\eproc-jmto\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-07-06 23:57:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\eproc-jmto\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-07-06 23:57:51 --> Unable to connect to the database
ERROR - 2023-07-06 23:57:52 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=2596 C:\laragon\www\eproc-jmto\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-07-06 23:57:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\eproc-jmto\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-07-06 23:57:52 --> Unable to connect to the database
ERROR - 2023-07-06 23:58:27 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=2596 C:\laragon\www\eproc-jmto\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-07-06 23:58:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\eproc-jmto\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-07-06 23:58:27 --> Unable to connect to the database
