<main class="container-fluid">
    <div class="row">
        <div class="col">
            <div class="card border-dark">
                <div class="card-header border-dark swatch-purple d-flex justify-content-between align-items-center">
                    <div class="flex-grow-1 bd-highlight">
                        <span class="text-white">
                            <i class="fa-solid fa-table px-1"></i>
                            <small><strong>Data Tabel - Sertifikat Badan Usaha (SBU)</strong></small>
                        </span>
                    </div>
                    <div class="bd-highlight">
                        <button type="button" class="btn btn-primary btn-sm shadow-lg" data-bs-toggle="modal" data-bs-target="#modal-xl-tambah">
                            <i class="fa-solid fa-circle-plus px-1"></i>
                            Create Data
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <input type="hidden" name="url_get_nib" value="<?= base_url('validator/data_sbu/get_data_sbu') ?>">
                    <input type="hidden" name="url_get_row" value="<?= base_url('validator/data_sbu/get_row_data/') ?>">
                    <input type="hidden" name="url_post" value="<?= base_url('validator/data_sbu/post_data') ?> ">
                    <input type="hidden" name="url_aktifkan_sbu" value="<?= base_url('validator/data_sbu/aktifkan_sbu') ?> ">
                    <table id="example1" class="table table-bordered table-sm table-striped">
                        <thead class="bg-secondary">
                            <tr>
                                <th style="width:5%;"><small class="text-white">No</small></th>
                                <th style="width:10%;"><small class="text-white">Kode SBU</small></th>
                                <th style="width:35%;"><small class="text-white">Jenis SBU</small></th>
                                <th style="width:15%;"><small class="text-white">Status Data</small></th>
                                <th style="width:20%;"><small class="text-white">
                                        <div class="text-center">More Options</div>
                                    </small></th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" tabindex="-1" id="modal-xl-tambah">
        <div class="modal-dialog modal-dialog-scrollable modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <a class="navbar-brand">
                        <img src="<?php echo base_url(); ?>/assets/brand/jm1.png" alt="" width="25" height="25" class="d-inline-block align-text-top">
                        <b><span class="text-primary">Jasamarga Tollroad Operator</span></b>
                    </a>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col">
                            <div class="card border-dark shadow-lg">
                                <div class="card-header border-dark swatch-purple d-flex justify-content-between align-items-center">
                                    <div class="flex-grow-1 bd-highlight">
                                        <span class="text-dark">
                                            <i class="fa-regular fa-rectangle-list px-1"></i>
                                            <small><strong>Form Data - Sertifikat Badan Usaha (SBU)</strong></small>
                                        </span>
                                    </div>
                                    <div class="bd-highlight">
                                        <button type="button" class="btn btn-primary btn-sm shadow-lg" disabled>
                                            <i class="fa-solid fa-pen-to-square px-1"></i>
                                            Edit Data
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <form>
                                        <div class="row g-1">
                                            <div class="col-sm-3">
                                                <div class="input-group mb-2">
                                                    <span class="input-group-text"><i class="fa-solid fa-barcode"></i></span>
                                                    <input type="text" class="form-control" placeholder="Kode SBU">
                                                </div>
                                            </div>
                                            <div class="col-sm-9">
                                                <div class="input-group mb-2">
                                                    <span class="input-group-text"><i class="fa-solid fa-keyboard"></i></span>
                                                    <input type="text" class="form-control" placeholder="Jenis SBU">
                                                </div>
                                            </div>
                                            <div class="col-sm-2">
                                                <button type="button" class="btn btn-success btn-sm shadow-lg" disabled>
                                                    <i class="fa-solid fa-floppy-disk px-1"></i>
                                                    Save Data
                                                </button>
                                            </div>
                                        </div>
                                        </from>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer d-flex justify-content-start">
                    <button type="button" class="btn btn-sm btn-danger" data-bs-dismiss="modal">
                        <i class="fa-solid fa-rectangle-xmark"></i>
                        Close
                    </button>
                </div>
            </div>
        </div>
    </div>
</main>